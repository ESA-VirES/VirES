#/bin/sh
find ./mapscript -name \*.i -exec sed -i -e 's/\([%#]include "\)\.\.\/\.\.\(\/[a-z0-9-]\+\.h"\)/\1mapserver\2/' {} \;
